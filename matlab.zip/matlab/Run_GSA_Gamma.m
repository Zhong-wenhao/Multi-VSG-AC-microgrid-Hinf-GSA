function Run_GSA_Gamma()
    clc; close all;
    tic;

    % fun1_three_Hinf.m lives in ./3-VSG, not in this folder
    thisdir = fileparts(mfilename('fullpath'));
    if ~isempty(thisdir), addpath(fullfile(thisdir, '3-VSG')); end

    %% GSA参数
    n_vars  = 10;
    sizepop = 20;
    maxgen  = 30;
    G0      = 100;
    alpha   = 10;
    epsilon = 1e-12;

    boundary_margin  = 1e-4;
    boundary_damping = 0.5;
    vmax = 0.2;

    %% 参数范围
    Lb = [50, 1, 0.05, 10, 10, 0.01, 0.25, 0.1, 1, 2];
    Ub = [150, 10, 1, 100, 100, 0.5, 30, 5, 100, 20];

    %% 初始化
    U = boundary_margin + ...
        (1 - 2 * boundary_margin) .* rand(sizepop, n_vars);
    V = zeros(sizepop, n_vars);
    fitness = inf(sizepop, 1);

    for k = 1:sizepop
        fitness(k) = ObjectiveFunctionSafe(DecodeParam(U(k,:), Lb, Ub));
    end

    [best_gamma, best_idx] = min(fitness);
    best_param = DecodeParam(U(best_idx,:), Lb, Ub);
    best_history = zeros(maxgen, 1);

    %% GSA主循环
    for t = 1:maxgen
        G = G0 * exp(-alpha * t / maxgen);

        best_fit = min(fitness);
        worst_fit = max(fitness);

        if abs(best_fit - worst_fit) < epsilon
            M = ones(sizepop, 1) / sizepop;
        else
            m = (fitness - worst_fit) ./ ...
                (best_fit - worst_fit + epsilon);
            m(~isfinite(m) | m < 0) = 0;

            if sum(m) <= epsilon
                M = ones(sizepop, 1) / sizepop;
            else
                M = m / sum(m);
            end
        end

        Kbest = max(1, round(sizepop - (sizepop - 1) * t / maxgen));
        [~, order] = sort(M, 'descend');
        active_agents = order(1:Kbest);

        a = zeros(sizepop, n_vars);
        for i = 1:sizepop
            for jj = 1:Kbest
                j = active_agents(jj);
                if i ~= j
                    distance = norm(U(j,:) - U(i,:));
                    a(i,:) = a(i,:) + rand(1, n_vars) .* ...
                        (G * M(j) / (distance + epsilon)) .* ...
                        (U(j,:) - U(i,:));
                end
            end
        end

        V = rand(sizepop, n_vars) .* V + a;
        V = max(min(V, vmax), -vmax);

        [U, V] = ReflectBoundary(U + V, V, boundary_margin, ...
                                 1 - boundary_margin, boundary_damping);

        for k = 1:sizepop
            fitness(k) = ObjectiveFunctionSafe(DecodeParam(U(k,:), Lb, Ub));
        end

        [current_best, best_idx] = min(fitness);
        if current_best < best_gamma
            best_gamma = current_best;
            best_param = DecodeParam(U(best_idx,:), Lb, Ub);
        end

        best_history(t) = best_gamma;
        fprintf('Iter %d/%d, Best Gamma = %.6f\n', ...
                t, maxgen, best_gamma);
    end

    %% 输出10个最优参数，保留4位小数
    fprintf('\nMinimum Gamma: %.4f\n', best_gamma);
    param_names = {'cv','cq','k_pv','k_iv','k_pc', ...
                   'k_pQ','k_iQ','k_pf','k_if','cw'};

    for j = 1:n_vars
        fprintf('%-5s = %.4f\n', param_names{j}, best_param(j));
    end

    %% 收敛曲线
    figure('Color', 'w');
    plot(best_history, 'LineWidth', 2);
    xlabel('Iteration');
    ylabel('Best \gamma');
    title('GSA Convergence Curve');
    grid on;

    %% 保存结果
    save('GSA_single_result.mat', 'best_gamma', 'best_param', ...
         'best_history', 'Lb', 'Ub', 'sizepop', 'maxgen', ...
         'G0', 'alpha', 'boundary_margin', ...
         'boundary_damping', 'vmax');

    toc;
end

function theta = DecodeParam(u, Lb, Ub)
    theta = Lb + u .* (Ub - Lb);
end

function [U, V] = ReflectBoundary(U, V, low, high, damping)
    out_flag = (U < low) | (U > high);
    if ~any(out_flag(:))
        return;
    end

    interval = high - low;
    U = low + mod(U - low, 2 * interval);

    over_high = U > high;
    U(over_high) = high - (U(over_high) - high);
    U = max(min(U, high), low);
    V(out_flag) = -damping .* V(out_flag);
end

function gamma = ObjectiveFunctionSafe(theta)
    try
        [~, ~, Ainv_H, Finv_H, Hinv_H, C_z] = ...
            fun1_three_Hinf(theta(1), theta(2), theta(3), theta(4), ...
                            theta(5), theta(6), theta(7), theta(8), ...
                            theta(9), theta(10));

        gamma = gamma_solver(Ainv_H, Finv_H, Hinv_H, C_z);

        if isempty(gamma) || ~isnumeric(gamma) || ...
                ~isfinite(gamma) || ~isreal(gamma)
            gamma = 1e12;
        else
            gamma = real(gamma);
        end
    catch ME
        gamma = 1e12;
        fprintf('Objective failed: %s\n', ME.message);
    end
end
