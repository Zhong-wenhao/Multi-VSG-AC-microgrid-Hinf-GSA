function gamma = gamma_solver(A, Ad, Bw, C)
    % gamma_solver: Solve H-infinity gamma via LMI optimization
    % Inputs:  A, Ad, Bw, C (system matrices)
    % Outputs: gamma (H-infinity norm bound)

    tau = 0.05;
    n = size(A,1);

    yalmip('clear');
    P = sdpvar(n, n, 'symmetric');
    Q = sdpvar(n, n, 'symmetric');
    R = sdpvar(n, n, 'symmetric');
    gamma2 = sdpvar(1, 1);
    tau2 = tau * tau;

    Phi11 = A'*P + P*A + Q + tau2*A'*R*A + C'*C - 4*R;
    Phi12 = P*Ad + tau2*A'*R*Ad - 2*R;
    Phi13 = P*Bw + tau2*A'*R*Bw;
    Phi14 = 6*R;
    Phi22 = tau2*Ad'*R*Ad - Q - 4*R;
    Phi23 = tau2*Ad'*R*Bw;
    Phi24 = 6*R;
    Phi33 = tau2*Bw'*R*Bw - gamma2*eye(size(Bw,2));
    Phi34 = zeros(size(Bw,2), n);
    Phi44 = -12*R;

    LMI = [Phi11 Phi12 Phi13 Phi14;
           (Phi12)' Phi22 Phi23 Phi24;
           (Phi13)' (Phi23)' Phi33 Phi34;
           (Phi14)' (Phi24)' (Phi34)' Phi44];

    F = [P>=0, Q>=0, R>=0, LMI<=0];
    ops = sdpsettings('solver', 'mosek', 'verbose', 0, 'warning', 0);
    sol = optimize(F, gamma2, ops);

    value = double(gamma2);
    gamma = sqrt(value)
end
