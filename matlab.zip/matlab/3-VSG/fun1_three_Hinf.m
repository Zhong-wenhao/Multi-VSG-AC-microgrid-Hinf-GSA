function [A_sys,A_sysd,Ainv_H,Finv_H,Hinv_H,C_z] = fun1_three_Hinf(cv,cq,k_pv,k_iv,k_pc,k_pQ,k_iQ,k_pf,k_if,cw)
cv = abs(cv);
cq = abs(cq);
cw = abs(cw);
ng = 3;
order0 = 14;
order = 15;     
n = [3.89e-3 3.89e-3 3.89e-3];
L_f = 0.3e-2;    
R_f = 0.2;
C_f = 20e-6;       
L_l = [0.2e-2 0.15e-2 0.18e-2];
R_l = [0.2    0.12    0.15];
L_load = 0.02168;
R_load = 6.807;
w_c = 50;         
w_n = 314;
w = [314.2 314.2 314.2];
w_com = w(1);
delta = [0 -6.428e-5 0.008003];
I_ld = [ 10.17 10.23 10.2];
I_lq = [-9.309 -9.615 -9.38];
V_od = [319.6 317 318.4];
V_oq = [-15.55 -15.66 -15.84];
I_od = [10.05 10.11 10.08];
I_oq = [-11.37 -11.41 -11.43];
I_loadD = 32.33;
I_loadQ = -32.26;
V_bD = 311;
V_bQ = -0.1275;
r_N = 1000;
k_QL = 1.2e-4;
k_QR = 0.02;
L_star = 0.005;
R_star = 0.05;
kw = 1/3;
J = [1.5 1.5 1.5];
D = [50 50 50];  
P_ref = [5000 5000 5000];
AIJ = [0 1 1; 1 0 1; 1 1 0];
gV = [1 1 1];      
gW = [1 1 1];    
A_cell = cell(ng,1);
B_cell = cell(ng,1);
Bw_cell = cell(ng,1);
H_cell = cell(ng,1);
Cc_cell = cell(ng,1);
F_cell = cell(ng,ng);
BLC3_cell = cell(ng,1);
gamma_vsg = zeros(1,ng);
for i = 1:ng
    deg_i = sum(AIJ(i,:));
    P0_i = 1.5*(V_od(i)*I_od(i) + V_oq(i)*I_oq(i));
    % gamma_vsg(i) = (P_ref(i)-P0_i)/(J(i)*w(i)^2);
    gamma_vsg(i) = 0;
    A_p = zeros(4,4);
    A_p(1,2) = 1;
    A_p(2,2) = -D(i)/J(i) - gamma_vsg(i);
    A_p(2,3) = -1/(J(i)*w(i));
    A_p(3,3) = -w_c;
    A_p(4,4) = -w_c;
    B_pwcom = [-1; 0; 0; 0];
    C_pw_i = [0 1 0 0];
    C_pv_i = [0 0 0 -n(i); 0 0 0 0];
    B_p_i = 1.5*w_c*[zeros(2,6);
        0 0 I_od(i)  I_oq(i)  V_od(i) V_oq(i);
        0 0 -I_oq(i) I_od(i)  V_oq(i) -V_od(i)];
    B_v1 = eye(2);
    B_v2 = [0 0 -1 0 0 0; 0 0 0 -1 0 0];
    C_v_i = [k_iv 0; 0 k_iv];
    D_v1_i = [k_pv 0; 0 k_pv];
    D_v2_i = [0 0 -k_pv -w_n*C_f 0 0;
              0 0  w_n*C_f -k_pv 0 0];
    D_c1_i = [k_pc 0; 0 k_pc];
    D_c2_i = [-k_pc -w_n*L_f 0 0 0 0;
               w_n*L_f -k_pc 0 0 0 0];
    A_LC_i = [-R_f/L_f  w(i)       -1/L_f 0       0          0;
              -w(i)    -R_f/L_f     0    -1/L_f  0          0;
               1/C_f    0           0     w(i)   -1/C_f     0;
               0        1/C_f      -w(i)  0       0         -1/C_f;
               0        0           1/L_l(i) 0   -R_l(i)/L_l(i)  w(i);
               0        0           0    1/L_l(i) -w(i)    -R_l(i)/L_l(i)];
    B_LC1_i = [1/L_f 0; 0 1/L_f; zeros(4,2)];
    B_LC2_i = [zeros(4,2); -1/L_l(i) 0; 0 -1/L_l(i)];
    B_LC3_i = [I_lq(i) -I_ld(i) V_oq(i) -V_od(i) I_oq(i) -I_od(i)]';
    BLC3_cell{i} = B_LC3_i;
    T_s_i = [cos(delta(i)) -sin(delta(i)); sin(delta(i)) cos(delta(i))];
    T_c_i = [-I_od(i)*sin(delta(i))-I_oq(i)*cos(delta(i));
              I_od(i)*cos(delta(i))-I_oq(i)*sin(delta(i))];
    T_u_i = [cos(delta(i)) sin(delta(i)); -sin(delta(i)) cos(delta(i))];
    T_v_i = [-V_bD*sin(delta(i))+V_bQ*cos(delta(i));
             -V_bD*cos(delta(i))-V_bQ*sin(delta(i))];
    A_h_i = [0 0 0 -cq*deg_i*n(i)];
    A_g_i = [0 0 0 cv*(deg_i+gV(i))*n(i)];
    B_g_i = -cv*(deg_i+gV(i));
    Kvv_i = [k_pQ*(k_QL*I_oq(i)*w_n-k_QR*I_od(i));
            -k_pQ*(k_QL*I_od(i)*w_n+k_QR*I_oq(i))];
    A_vv_i = Kvv_i*A_h_i;
    C_vv_i = [zeros(1,3) Kvv_i(1);
              zeros(1,3) Kvv_i(2)];
    B_vv_i = [zeros(1,4) R_star -L_star;
              zeros(1,4) L_star  R_star];
    D_vv_i = [k_iQ*(k_QL*I_oq(i)*w_n-k_QR*I_od(i));
             -k_iQ*(k_QL*I_od(i)*w_n+k_QR*I_oq(i))];
    D_pf = [1;0];
    BLK1_1 = A_p;
    BLK1_2 = zeros(4,2);
    BLK1_3 = B_p_i;
    BLK1_4 = zeros(4,1);
    BLK1_5 = zeros(4,1);
    BLK2_1 = B_v1*(C_pv_i - A_vv_i);
    BLK2_2 = zeros(2,2);
    BLK2_3 = -B_v1*B_vv_i + B_v2;
    BLK2_4 = B_v1*D_pf;
    BLK2_5 = -B_v1*D_vv_i;
    term_LC1_Dc1_Dv1 = B_LC1_i*D_c1_i*D_v1_i;
    term_Tv_expanded = [T_v_i zeros(2,3)];
    BLK3_1 = term_LC1_Dc1_Dv1*(C_pv_i - A_vv_i) + B_LC3_i*C_pw_i + B_LC2_i*term_Tv_expanded;
    BLK3_2 = B_LC1_i*D_c1_i*C_v_i;
    BLK3_3 = A_LC_i + B_LC1_i*(D_c1_i*D_v2_i - D_c1_i*D_v1_i*B_vv_i + D_c2_i);
    BLK3_4 = B_LC1_i*D_c1_i*D_v1_i*D_pf;
    BLK3_5 = -B_LC1_i*D_c1_i*D_v1_i*D_vv_i;
    BLK4_1 = A_g_i;
    BLK4_2 = zeros(1,2);
    BLK4_3 = zeros(1,6);
    BLK4_4 = B_g_i;
    BLK4_5 = 0;
    BLK5_1 = A_h_i;
    BLK5_2 = zeros(1,2);
    BLK5_3 = zeros(1,6);
    BLK5_4 = 0;
    BLK5_5 = 0;
    A14 = [BLK1_1 BLK1_2 BLK1_3 BLK1_4 BLK1_5;
           BLK2_1 BLK2_2 BLK2_3 BLK2_4 BLK2_5;
           BLK3_1 BLK3_2 BLK3_3 BLK3_4 BLK3_5;
           BLK4_1 BLK4_2 BLK4_3 BLK4_4 BLK4_5;
           BLK5_1 BLK5_2 BLK5_3 BLK5_4 BLK5_5];
    B14  = [zeros(6,2); B_LC2_i*T_u_i; zeros(2,2)];
    Bw14 = [B_pwcom; zeros(10,1)];
    H14  = [zeros(12,1); cv*gV(i); 0];
    Cc14 = [T_c_i zeros(2,9) T_s_i zeros(2,2)];
    A_cell{i} = [A14 zeros(order0,1); zeros(1,order)];
    B_cell{i} = [B14; zeros(1,2)];
    Bw_cell{i} = [Bw14; 0];
    H_cell{i} = [H14; 0];
    Cc_cell{i} = [Cc14 zeros(2,1)];
    for j = 1:ng
        F14 = [zeros(4,14);
               -B_v1*C_vv_i*cq*AIJ(i,j)*n(j) zeros(2,10);
               -B_LC1_i*D_c1_i*D_v1_i*C_vv_i*cq*AIJ(i,j)*n(j) zeros(6,10);
               zeros(1,3) -cv*AIJ(i,j)*n(j) zeros(1,8) cv*AIJ(i,j) 0;
               zeros(1,3) cq*AIJ(i,j)*n(j) zeros(1,8) 0 0];
        F_cell{i,j} = [F14 zeros(order0,1); zeros(1,order)];
    end
end
% === Assemble global inverter model ===
A_inv_hat = zeros(ng*order, ng*order);
B_inv_hat = zeros(ng*order, 2*ng);
B_wcom_hat = zeros(ng*order, 1);
H_inv_hat = zeros(ng*order, 1);
C_invc_hat = zeros(2*ng, ng*order);
F_inv_hat = zeros(ng*order, ng*order);
for i = 1:ng
    ri = (i-1)*order + (1:order);
    ci = ri;
    A_inv_hat(ri,ci) = A_cell{i};
    B_inv_hat(ri,2*i-1:2*i) = B_cell{i};
    B_wcom_hat(ri,1) = Bw_cell{i};
    H_inv_hat(ri,1) = H_cell{i};
    C_invc_hat(2*i-1:2*i,ci) = Cc_cell{i};
    for j = 1:ng
        cj = (j-1)*order + (1:order);
        F_inv_hat(ri,cj) = F_cell{i,j};
    end
end
Cw_com_delta = zeros(1,ng*order);
Cw_com_delta(2) = 1;
A_inv_hat = A_inv_hat + B_wcom_hat*Cw_com_delta;
idx_w  = 2:order:ng*order;
idx_xi = order:order:ng*order;
Cw_sec = zeros(1,ng*order);
Cw_sec(idx_xi) = kw;

for i = 1:ng
    ri = (i-1)*order;
    A_inv_hat(ri+2,:) = A_inv_hat(ri+2,:) - gamma_vsg(i)*Cw_sec;
    A_inv_hat(ri+7:ri+12,:) = A_inv_hat(ri+7:ri+12,:) + BLC3_cell{i}*Cw_sec;
end
for i = 1:ng
    row = (i-1)*order + order;
    deg_i = sum(AIJ(i,:));
    A_inv_hat(row,idx_w(i)) = A_inv_hat(row,idx_w(i)) - cw*(deg_i+gW(i));
    A_inv_hat(row,idx_xi) = A_inv_hat(row,idx_xi) - cw*(deg_i+gW(i))*kw;
    for j = 1:ng
        if AIJ(i,j) ~= 0
            F_inv_hat(row,idx_w(j)) = F_inv_hat(row,idx_w(j)) + cw*AIJ(i,j);
            F_inv_hat(row,idx_xi) = F_inv_hat(row,idx_xi) + cw*AIJ(i,j)*kw;
        end
    end
end

C_invw_hat = zeros(1,ng*order);
C_invw_hat(idx_w(1)) = 1;
C_invw_hat(idx_xi) = kw;

B_inv_pcc_hat = zeros(ng*order, 2);
for ii = 1:ng
    ri = (ii-1)*order + (1:order);
    B_inv_pcc_hat(ri,:) = B_cell{ii};
end
% === Network and load ===
A_load = [-R_load/L_load w_com; -w_com -R_load/L_load];
B_1load = [1/L_load 0; 0 1/L_load];
B_2load = [I_loadQ; -I_loadD];

M_inv  = [r_N 0 r_N 0 r_N 0;
          0 r_N 0 r_N 0 r_N];      % 2 x (2*ng)
M_load = [-r_N 0;
           0 -r_N];                 % 2 x 2

V_pccD0 = V_bD;
V_pccQ0 = V_bQ;
V_pcc0 = sqrt(V_pccD0^2 + V_pccQ0^2);
A_pcc = [V_pccD0/V_pcc0 V_pccQ0/V_pcc0];

Ainv_H = [A_inv_hat+B_inv_pcc_hat*M_inv*C_invc_hat, B_inv_pcc_hat*M_load;
          B_1load*M_inv*C_invc_hat+B_2load*C_invw_hat, A_load+B_1load*M_load];
Finv_H = [F_inv_hat zeros(ng*order,2);
          zeros(2,ng*order) zeros(2,2)];
Hinv_H = [H_inv_hat; zeros(2,1)];

A_sys = [A_inv_hat+B_inv_pcc_hat*M_inv*C_invc_hat - k_pf*H_inv_hat*A_pcc*M_inv*C_invc_hat, ...
         B_inv_pcc_hat*M_load - k_pf*H_inv_hat*A_pcc*M_load, ...
         k_if*H_inv_hat;
         B_1load*M_inv*C_invc_hat+B_2load*C_invw_hat, ...
         A_load+B_1load*M_load, zeros(2,1);
         -A_pcc*M_inv*C_invc_hat, -A_pcc*M_load, 0];

A_sysd = [F_inv_hat zeros(ng*order,3);
          zeros(3,ng*order+3)];

C_z = zeros(2*ng, size(Ainv_H,1));
for ii = 1:ng
    base = (ii-1)*order;
    C_z(2*ii-1, base+9)  = 1;
    C_z(2*ii,   base+10) = 1;
end

end
